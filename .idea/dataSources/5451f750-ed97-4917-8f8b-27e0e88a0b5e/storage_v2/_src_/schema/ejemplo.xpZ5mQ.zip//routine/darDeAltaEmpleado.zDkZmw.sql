create
    definer = root@localhost procedure darDeAltaEmpleado(IN apellido varchar(15), IN DIR varchar(30),
                                                         IN SALARIO float(6, 2), IN idE tinyint)
BEGIN
	
    INSERT INTO ejemplo.empleados (apellido, DIR,SALARIO, idE)
		VALUES (apellido,DIR,current_date(),SALARIO,idE);
        
END;

