create
    definer = root@localhost function getDepartamentoMayor() returns tinyint
BEGIN

    SELECT idD, count(*) as cuenta into @idnum, @idconteo from empleados group by idD ORDER BY cuenta DESC LIMIT 1;

    RETURN @idnum;
END;

