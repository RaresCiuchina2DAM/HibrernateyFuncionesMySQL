create
    definer = root@localhost function obtenerdepartamentomayornumempleados() returns tinyint
    comment 'CREAR UNA FUNCION EN MYSQL PARA OBTENER EL DEPARTAMENTO CON MAYOR NUMERO DE EMPLEADOS;'
BEGIN

DECLARE nombreDpto TINYINT;


select nombreDpto, count(*) as num_empleados into nombreDpto from
empleados group by nombreDpto order by num_empleados desc
limit 1 ;

RETURN nombreDpto;

END;

